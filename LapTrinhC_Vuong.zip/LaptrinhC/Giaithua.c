#include<stdio.h>
void GT(int a)
{ 
  float s =1;
  for(int i=1;i<=a;i++)
   {
	s= s*i;
   }
  printf("ket qua: %f",s);
}
