#include<stdio.h>
void hello(char *name)
{
  printf("Hello %s \n ",name);
}
