void hello(char* name);
void bonjour(char* name);
void GT(int a);
void TinhTong(int n);
void TinhTongle(int n);
void TinhLuyThua(int a,int b);
