#include<stdio.h>
#include "mylib.h"
int main()
{
 GT(100);
 printf("\n");
 TinhTong(100);
 printf("\n");
 TinhTongle(100);
 printf("\n");
 TinhLuyThua(3,2);
 printf("\n");
}
