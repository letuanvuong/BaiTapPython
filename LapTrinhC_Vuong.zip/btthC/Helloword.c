#include<stdio.h>
#include "mylib.h"
int main()
{
   hello("toan");
   bonjour("Toan");
return 0;
}
