from bikeu import Vuong 
sv1 = Vuong()
sv1.set_ten()
sv1.set_sdt()
print ("Thông tin")
sv1.In()
