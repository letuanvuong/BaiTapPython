"""
n = int(input("n= "))
s = 0
for i in range(1, n+1):
	s = s + i
print("Tổng chuỗi:  ",s)
"""
"""for i in range (1, 11):
	print ("", i)"""
'''def Tong(a, b):
	return a+b
print ("Tong: ",Tong(3,5))
'''
#Nhập mảng từ b phím
'''list = []
n = int(input("n= "))
for i in range(0, n):
	a = input("So thu nhat: ")
	list.append(a)
for i in range (0, n):
	print(list[i])	'''

		
